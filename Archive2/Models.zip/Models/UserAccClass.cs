﻿using System;
using System.Collections.Generic;

#nullable disable

namespace modelfor_archive.Models
{
    public partial class UserAcc
    {
        public UserAcc()
        {
            Messages = new HashSet<Message>();
        }

        public int UserId { get; set; }
        public string UserName { get; set; }
        public string AcadMail { get; set; }
        public string Pass { get; set; }
        public string JobTitle { get; set; }
        public string Phone { get; set; }

        public virtual ICollection<Message> Messages { get; set; }
    }
}